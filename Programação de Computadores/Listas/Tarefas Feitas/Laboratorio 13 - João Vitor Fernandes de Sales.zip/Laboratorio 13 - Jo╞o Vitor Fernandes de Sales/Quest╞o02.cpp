#include<iostream>
using namespace std;

	union jogador
	{
		char nome[25]; // nome do jogador
		int numero; // numero da camisa do jogador
	};
	struct gol
	{
		jogador jog; // identifica��o do jogador
		int hora, min; // hora e minuto em que o gol foi marcado
	};

int main() 
{
	//Declara��o das variaveis
	gol golasso[3];
	char pontos;
	int contador = 0;

	cout << "Qual informacao voce deseja armazenar do jogador ? "<< endl;
	cout << "Digite [1] para o nome ou digite [2] para o numero da camisa: " << endl;
	unsigned short valor;
	cin >> valor;
	
	jogador opcao[3];
	if (valor == 1) {
		cout << "Digite os dados dos 3 ultimos gols:" << endl;
		cout << "Digite o nome do jogador: ";
		cin.get();
		cin.getline(opcao[0].nome,25);
		cout << "Digite o horario do gol: ";
		cin >> golasso[0].hora >> pontos >> golasso[0].min;
		cout << "Digite o nome do jogador: ";
		cin.get();
		cin.getline(opcao[1].nome, 25);
		cout << "Digite o horario do gol: ";
		cin >> golasso[1].hora >> pontos >> golasso[1].min;
		cout << "Digite o nome do jogador: ";
		cin.get();
		cin.getline(opcao[2].nome, 25);
		cout << "Digite o horario do gol: ";
		cin >> golasso[2].hora >> pontos >> golasso[2].min;
		cout << "Gol: " << opcao[0].nome << " " << golasso[0].hora << pontos << golasso[0].min << endl;
		cout << "Gol: " << opcao[1].nome << " " << golasso[1].hora << pontos << golasso[1].min << endl;
		cout << "Gol: " << opcao[2].nome << " " << golasso[2].hora << pontos << golasso[2].min;
	}
	else if (valor == 2) {
		cout << "Digite os dados dos 3 ultimos gols:" << endl;
		cout << "Digite o numero da camisa do jogador: ";
		cin >> opcao[0].numero;
		cout << "Digite o horario do gol: ";
		cin >> golasso[0].hora >> pontos >> golasso[0].min;
		cout << "Digite o numero da camisa do jogador: ";
		cin >> opcao[1].numero;
		cout << "Digite o horario do gol: ";
		cin >> golasso[1].hora >> pontos >> golasso[1].min;
		cout << "Digite o numero da camisa do jogador: ";
		cin >> opcao[2].numero;
		cout << "Digite o horario do gol: ";
		cin >> golasso[2].hora >> pontos >> golasso[2].min;
		cout << "Gol: " << opcao[0].numero << " " << golasso[0].hora << pontos << golasso[0].min << endl;
		cout << "Gol: " << opcao[1].numero << " " << golasso[1].hora << pontos << golasso[1].min << endl;
		cout << "Gol: " << opcao[2].numero << " " << golasso[2].hora << pontos << golasso[2].min;
	}
	else {
		cout << "Opcao nao encontrada !";
	}
}