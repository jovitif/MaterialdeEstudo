#include <iostream>
using namespace std;

enum semana { SEG, TER, QUA, QUI, SEX, SAB, DOM};   //Cria��o de uma enumera��o, para formar as constantes
//SEG = 0, TER = 1, QUA = 2, QUI = 3, SEX = 4, SAB = 5, DOM = 6

int main()
{
	char sem[7][10] =								//Cria��o de uma matriz 7x10
	{
   "Segunda","Terca","Quarta","Quinta","Sexta","Sabado","Domingo"
	};
	//Vamos supor que ind seja uma constante do tipo semana, ent�o posso afirmar que ele pode ser = SEG = 0	ou ind seja < = DOM = 5
	//Nesse caso ele irar somar +1 at� chegar no 6 e irar escrever na tela o sem[ind] que irar percorrer todos os valores
	for (semana ind = SEG; ind <= DOM; ind = semana(ind + 1))			//Cria��o de um la�o de repeti��o
		cout << sem[ind] << endl;
	return 0;
}