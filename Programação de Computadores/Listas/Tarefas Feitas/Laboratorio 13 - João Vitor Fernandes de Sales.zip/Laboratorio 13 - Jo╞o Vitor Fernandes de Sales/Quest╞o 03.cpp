#include<iostream>
using namespace std;


	//a. Data (um registro que possui tr�s valores inteiros � dia, m�s e ano)
	struct date {
		unsigned short dia, mes, ano;
	};

	//b. Hor�rio (um registro que possui dois valores inteiros � hora e minuto)
	struct horario {
		unsigned short hora, minuto;
	};

	struct evento {
		date dat;
		horario hor;
		char descricao[18];
	};


int main()
{
	evento eventos[10]; //O vetor eventos ira ser do tipo evento
	

	cout << "Entre com dois eventos: \n";
	cout << "#1 \n";
	cout << "Data: ";
	cin >> eventos[0].dat.dia;
	cin >> eventos[0].dat.mes;
	cin >> eventos[0].dat.ano;
	cout << "Hora: ";
	cin >> eventos[0].hor.hora;
	cin >> eventos[0].hor.minuto;
	cout << "Descricao: ";
	cin.get();
	cin.getline(eventos[0].descricao, 18);
	cout << "#2 \n";
	cout << "Data: ";
	cin >> eventos[1].dat.dia;
	cin >> eventos[1].dat.mes;
	cin >> eventos[1].dat.ano;
	cout << "Hora: ";
	cin >> eventos[1].hor.hora;
	cin >> eventos[1].hor.minuto;
	cout << "Descricao: ";
	cin.get();
	cin.getline(eventos[1].descricao, 18);
	cout << "--------------------\n";
	cout << "Eventos Cadastrados\n";
	cout.width(2); cout.fill('0'); 
	cout << eventos[0].dat.dia << "/" << eventos[0].dat.mes << "/" << eventos[0].dat.ano << " " << eventos[0].hor.hora << ":" << eventos[0].hor.minuto << " " << eventos[0].descricao << endl;
	cout.width(2); cout.fill('0');
	cout << eventos[1].dat.dia << "/" << eventos[1].dat.mes << "/" << eventos[1].dat.ano << " " << eventos[1].hor.hora << ":" << eventos[1].hor.minuto << " " << eventos[1].descricao << endl;

}