#include<iostream>
using namespace std;

int main() {
	enum trave { LEsq, LDir, CantoEsq, CantoDir, Centro };
	union jogador
	{
		char nome[25];
		int numero;
	};
	struct gol
	{
		jogador jog; // identifica��o do jogador
		float x, y, z; // posi��o da bola nas coordenadas
		trave local; // onde a bola entrou
		float velo; // velocidade da bola
		float acel; // acelera��o da bola
	};
	gol estatistica[10]; // estat�sticas para at� 10 gols
}

//Resposta:

	/*
	i) estatistica                                           -> vetor do tipo gol
	j) estatistica[4]                                        -> vetor especifico na posi��o 04 do tipo gol
	k) estatistica[1].jog                                    -> variavel do tipo jogador
	l) estatistica->jog.numero                               -> variavel invalida
	m) (estatistica + 9)->local                              -> variavel invalida
	n) estatistica[2].velo                                   -> variavel do tipo float
	o) (estatistica + 1)->jog.nome[0]						 -> variavel invalida
	p) estatistica[6].acel                                   -> variavel do tipo float
	

	*/