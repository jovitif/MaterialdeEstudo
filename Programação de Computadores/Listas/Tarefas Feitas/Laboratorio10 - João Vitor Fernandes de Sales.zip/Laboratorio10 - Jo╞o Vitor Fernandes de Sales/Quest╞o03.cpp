#include<iostream>
using namespace std;

int main() 
{
	double vetores[03];                  //Declara��o do vetor com 3 posi��es
	cout << "Digite 3 valores do tipo ponto flutuante: ";
	cin >> vetores[00] >> vetores[01] >> vetores[02];
	double valor_total = vetores[00] * vetores[02] - vetores[01];
	cout << "(" << vetores[00] << " x " << vetores[02] << ") - " << vetores[01] << " = " << valor_total;
}