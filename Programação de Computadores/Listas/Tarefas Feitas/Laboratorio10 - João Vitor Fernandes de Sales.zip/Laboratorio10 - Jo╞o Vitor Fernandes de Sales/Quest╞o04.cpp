#include<iostream>
using namespace std;

int main() 
{
	
	int vet[5] = {10, 20, 30, 40, 50};
	vet[5] = 60;
	vet[5000] = 60;

	/*
	Em ambos os casos irar ocorrer a presen�a de erro, porque no primeiro caso, o vetor[5] j� est� ocupado pelo numero 50
	Ja no outro caso mesmo n�o existindo um valor atribuido ao numero 5000, vai ocorrer um erro, pelo fato do vetor ocupar somente
	5 posi��es no maximo.
	*/

}