#include<iostream>
using namespace std;

int main()                                                  //Fun��o Principal
{
	int vetor_numeros[05] = { 10,80,30,45,15 };            //Declara��o do vetor do tipo inteiro junto com o valor de cada bloco
	cout << "Vetor: " << vetor_numeros[00] << " " << vetor_numeros[01] << " " << vetor_numeros[02] << " " << vetor_numeros[03] << " " << vetor_numeros[04] << endl;
	cout << "---------------------" << endl;
	cout << "Alterar posicao: ";
	int valor_posicao;
	cin >> valor_posicao;
	cout << "Novo valor: ";
	int valor_novo;
	cin >> valor_novo;
	cout << "---------------------" << endl;
	if (valor_posicao == 1) {                             //Estrutura condicional
		vetor_numeros[00] = valor_novo;
		cout << "Vetor: " << " " << vetor_numeros[00] << " " << vetor_numeros[01] << " " << vetor_numeros[02] << " " << vetor_numeros[03] << " " << vetor_numeros[04];
	}
	else if (valor_posicao == 2) {
		vetor_numeros[01] = valor_novo;
		cout << "Vetor: " << " " << vetor_numeros[00] << " " << vetor_numeros[01] << " " << vetor_numeros[02] << " " << vetor_numeros[03] << " " << vetor_numeros[04];
	}
	else if (valor_posicao == 3) {
		vetor_numeros[02] = valor_novo;
		cout << "Vetor: " << " " << vetor_numeros[00] << " " << vetor_numeros[01] << " " << vetor_numeros[02] << " " << vetor_numeros[03] << " " << vetor_numeros[04];
	}
	else if (valor_posicao == 4) {
		vetor_numeros[03] = valor_novo;
		cout << "Vetor: " << " " << vetor_numeros[00] << " " << vetor_numeros[01] << " " << vetor_numeros[02] << " " << vetor_numeros[03] << " " << vetor_numeros[04];
	}
	else if (valor_posicao == 5) {
		vetor_numeros[04] = valor_novo;
		cout << "Vetor: " << " " << vetor_numeros[00] << " " << vetor_numeros[01] << " " << vetor_numeros[02] << " " << vetor_numeros[03] << " " << vetor_numeros[04];
	}
	else {                                  //Caso digite um numero que n�o se encaixa nas posi��es dos vetores
		cout << "O numero digitado nao entra nas opcoes desejadas";
	}
}