#include<iostream>
using namespace std;

int main() 
{
	float vetor_nota[3], nota_antiga, nota_nova;
	cout << "Digite as 3 notas tiradas na prova: ";
	cin >> vetor_nota[0] >> vetor_nota[1] >> vetor_nota[2];
	cout << " " << endl;
	cout << "Sua nota no sistema antigo foi: " << endl;
	cout << "---------------------------------" << endl;
	nota_antiga = (vetor_nota[0] * 2 + vetor_nota[1] * 3 + vetor_nota[2] * 4) / 9;

	cout << "media=(" << vetor_nota[0] << "*2+" << vetor_nota[1] << "*3+" << vetor_nota[2] << "*4)/9=" << nota_antiga << endl;
	cout << " " << endl;
	cout << "Sua nota no sistema novo foi: " << endl;
	cout << "---------------------------------" << endl;
	nota_nova = (vetor_nota[0] + vetor_nota[1] + vetor_nota[2]) / 3;
	cout << "media=(" << vetor_nota[0] << "+" << vetor_nota[1] << "+" << vetor_nota[2] << ")/3=" << nota_nova;

}