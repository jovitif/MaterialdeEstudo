#include <iostream>
using namespace std;

int main() 
{
	char vetor_nome[30];  //Primeiro vetor: vetor nome para armazenar o nome da pessoa digitada
	char vetor_data[11];  //Segundo vetor :vetor data para armazenas o dia
	const char vetor_concatenar[30] = " esteve aqui em ";   //Terceiro vetor: vetor concatenar para concatenar as frases
	cout << "Nome: ";
	cin.getline(vetor_nome, 30);
	cout << "Data: ";
	cin >> vetor_data;
	cout << vetor_nome << vetor_concatenar << vetor_data;

}