#include<iostream>
using namespace std;

int main() 
{
	char vetor_nome[10];
	char vetor_sobrenome[10];
	cout << "Digite seu nome e sobrenome: ";
	cin >> vetor_nome >> vetor_sobrenome;
	
	cout << "Bom dia senhor, " << vetor_sobrenome << ". Ou devo chama-lo de " << vetor_nome;

}