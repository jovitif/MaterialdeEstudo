#include <iostream>
#include <string>
using namespace std;

int main() 
{
	string num1;
	int num2,total;
	cout << "Entre com dois numeros: ";
	cin >> num1 >> num2;
	total = stoi(num1) * num2;
	cout << "A multiplicacao entre eles e " << total;
}