#include<iostream>
#include<string>
using namespace std;

int main() 
{
	string valor_senha;
	string senha_fixa = "Joaozinho1234";
	int contador = 0;
	cout << "Digite a senha: ";
	cin >> valor_senha;

	do{
		cout << "Senha incorreta!" << endl;
		cout << "Digite novamente!" << endl;
		cin >> valor_senha;
		contador = contador + 1;
	} while (valor_senha != senha_fixa);
	cout << "Senha correta!";
}