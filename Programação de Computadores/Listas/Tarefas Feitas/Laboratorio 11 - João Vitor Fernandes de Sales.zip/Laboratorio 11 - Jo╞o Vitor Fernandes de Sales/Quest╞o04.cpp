#include<iostream>
#include<string>
using namespace std;

int main()
{
	char data01[10];
	char data02[10];
	char data03[10];
	char vetor_natal[10] = "Natal";

	cout << "Quais suas datas comemorativas preferidas? " << endl;
	cin.getline(data01, 10);
	cin.getline(data02, 10);
	cin.getline(data03, 10);
	cout << "" << endl;

	if (data01[0] == vetor_natal[0] && data01[1] == vetor_natal[1] && data01[2] == vetor_natal[2] && data01[3] == vetor_natal[3] && data01[4] == vetor_natal[4]) {
		cout << data01 << ", " << data02 << " e " << data03 << " sao belas festas." << endl;
		cout << "O Natal tambem e uma das minhas datas preferidas!";
	}
	else if (data02[0] == vetor_natal[0] && data02[1] == vetor_natal[1] && data02[2] == vetor_natal[2] && data02[3] == vetor_natal[3] && data02[4] == vetor_natal[4]) {
		cout << data01 << ", " << data02 << " e " << data03 << " sao belas festas." << endl;
		cout << "O Natal tambem e uma das minhas datas preferidas!";
	}
	else if (data03[0] == vetor_natal[0] && data03[1] == vetor_natal[1] && data03[2] == vetor_natal[2] && data03[3] == vetor_natal[3] && data03[4] == vetor_natal[4]) {
		cout << data01 << ", " << data02 << " e " << data03 << " sao belas festas." << endl;
		cout << "O Natal tambem e uma das minhas datas preferidas!";
	}
	else {
		cout << data01 << ", " << data02 << " e " << data03 << " sao belas festas.";
	}
}