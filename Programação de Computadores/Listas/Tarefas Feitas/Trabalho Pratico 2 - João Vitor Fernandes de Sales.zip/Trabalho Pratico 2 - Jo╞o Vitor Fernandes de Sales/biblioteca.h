//biblioteca.h:arquivo de cabe�alho	contendo os	prot�tipos das fun��es do programa	e as defini��es	dos	registros

#ifndef BIBLIOTECA_H_INCLUDED
#define BIBLIOTECA_H_INCLUDED
#include<iostream>

//Declara��o dos registros dataevento e Biblioteca:
struct dataevento {
	int dia, mes, ano; //Componentes de cada data
};
struct Biblioteca {
	dataevento data_Inicial; /*Explica��o: antes eu estava criando a data_Inicial como sendo uma variavel do tipo dataevento
							 O que a principio dava certo no meu programa, entretando ficava dificil chama-la nas fun��es
							 resumo e total, ent�o notei que ela ambas as fun��es precisavam do ponteiro como argumento,
							 logo, adaptei meu programa para data_Inicial ser parte do registro, solucionando meu problema
							 com rela��o as duas fun��es*/
	int matricula; //Matr�cula	do	Aluno (n�mero com 10 d�gitos) 
	char indentificador[5]; //Identificador	do livro (c�digo com 5 letras)
};

void funcao_Traco(char caract, int valor); //Prototipo da funcao que recebe um caracter e um valor, com a finalidade de imprimir a quantidade desse caracter!

void funcao_Total(Biblioteca *pont,dataevento datfin, int num); /*Prototipo da funcao que recebe um vetor dinamico, 
																o seu tamanho e a data de devolu��o*/

void funcao_Resumo(Biblioteca pont, dataevento datfin);			 /*Prototipo da funcao que	receba o endere�o de um	registro empr�stimo e o	endere�o de
																  uma data de devolu��o	e exiba	os dados do	empr�stimo na
																  tela OBS03: Tive que adicionar um terceiro argumento que
																  � o tamanho, pois como ele vai rodar em um la�o de repeti��o
																  a unica forma que eu vi foi especificar para o contador que
																  ele tinha que rodar at� atingir o valor do tamanho.*/

int operator-(dataevento, dataevento); /*Fun��o usada para realizar as subtra��es entre as duas datas.*/
#endif
