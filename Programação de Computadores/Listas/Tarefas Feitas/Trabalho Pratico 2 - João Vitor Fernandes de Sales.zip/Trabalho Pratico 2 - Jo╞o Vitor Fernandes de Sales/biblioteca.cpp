//biblioteca.cpp:contendo a	implementa��o das fun��es definidas	em	biblioteca.h
#include "biblioteca.h"
#include <iostream>
using std::cin;
using std::cout;
using std::endl;
using std::fixed; //Tive que incluir o fixed, pois o programa n�o estava mostrando com as duas casas decimais!

/*
	Para	gerar	os	tra�os	separando	as	se��es	do	programa,	construa	e	use	uma
	fun��o	que	recebe	um	caractere	e	um	valor	inteiro	representando	o	tamanho	da
	linha	e	exiba na	tela	uma	linha	com	o	tamanho	indicado.
*/

void funcao_Traco(char caract, int valor) {
	for (int contador = 0; contador < valor; contador++) {
		cout << caract;
	}
}

//Fiz essa fun��o baseado na quest�o 03 do lab12
int operator-(dataevento hoje, dataevento inicial)
{
	//Criei um vetor dias_mes com 13 espa�os, para adicionar cada dia referente ao mes do ano
	int dias_mes[13] = { 0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
	int distancia, x; //Para fazer a subtra��o entre as duas datas
	unsigned long diferenca_ano = 0, idia, fdia; //A diferenca entre anos comeca com zero pois mais a frente sera somado no la�o de repeti��o
	x = (inicial.ano);
	
	idia = inicial.dia;
	
	for (int contador = inicial.mes - 1; contador > 0; --contador) {
		idia += dias_mes[contador];
	}
	fdia = hoje.dia;
	x = (hoje.ano);
	for (int contador = hoje.mes - 1; contador > 0; --contador) {
		fdia += dias_mes[contador];
	}
	for (int contador = 0; inicial.ano < inicial.ano; contador++) {
		diferenca_ano += 365 + (inicial.ano++);
	}
	distancia = ((diferenca_ano - idia + fdia) - 3); //Al�m de efetuar a diferen�a tive que subtrair 3, porque tem 3 dias de prazo!
	return distancia; 
}


void funcao_Resumo(Biblioteca pont, dataevento datfin) {
	//Com a ajuda do ponteiro o la�o vai passar por cada informa��o e exibira todas as informa��es que o funcionario digitou
	cout << pont.matricula << " " << pont.indentificador << " " << pont.data_Inicial.dia << "/0" << pont.data_Inicial.mes << "/" << pont.data_Inicial.ano << " -> " << "R$" << (datfin - pont.data_Inicial) * 0.80 << "\n";
}

void funcao_Total(Biblioteca* pont, dataevento datfin, int num) {
	float somatorio = 0.0; //Variavel inicializada com 0, para ir somando com os valores de cada dia
	cout << "Total em multas: R$";
	for (int i = 1; i <= num; i++) {
		somatorio = somatorio + ((datfin - pont[i].data_Inicial)*0.80);
	}
	cout.precision(2);
	cout << fixed << somatorio;
	cout << "\n"; funcao_Traco('-', 43);
	cout << "\n Encerrando programa...";
}
