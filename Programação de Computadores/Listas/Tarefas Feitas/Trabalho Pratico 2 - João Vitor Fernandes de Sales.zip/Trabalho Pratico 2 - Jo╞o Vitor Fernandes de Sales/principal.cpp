/*
	Trabalho Pratico 02 - Feito por Jo�o Vitor Fernandes de Sales
	principal.cpp: programa principal com a fun��o main()
	O vetor din�mico deve ser criado dentro	da fun��o main()
	O arquivo principal.cpp deve conter apenas uma fun��o, a fun��o main()
*/

/*
	OBS01: Tentei fazer o comando de acentua��o no pront de comando visto no seu canal, entretanto, o meu programa 
	n�o executava no pront de comando, ent�o decidi deixar sem acentua��o, para n�o correr o risco de zerar o trabalho!
	OBS02: Na parte de aloca��o dinamica na memoria tive que somar mais 1 ao tamanho pedido pelo funcionario, pois apos a
	execu��o do programa, aparecia uma mensagem de erro critico c0000374, ent�o eu decidi fazer uma pesquisa e achei o site:
	https://programmerah.com/vc-critical-error-detected-c0000374-crash-problem-and-solution-5833/ e vi que uma das solu��es
	seria somar + 1. Isso ajudou a deletar a memoria alocada, que tamb�m estava dando uma mensagem de erro.
*/

#include "biblioteca.h"	//Fazer a liga��o entre o arquivo .cpp e a biblioteca .h		 
#include<iostream>
#include<locale>
using std::cin;
using std::cout;
using std::endl;
using std::fixed; //Tive que incluir o fixed, pois o programa n�o estava mostrando com as duas casas decimais


int main() {
	setlocale(LC_ALL, "portuguese");
	dataevento data_Final; //Data referente a devolu��o.
	char Lixo; //variavel criada somente para receber o "/"
	
	cout << "Qual o n�mero de devolu��es para hoje? "; //Parte 01 - � perguntado ao funcionario o numero de devolu��es que vai ter:
	int numero_Devolucoes;
	cin >> numero_Devolucoes;
	/*Armazene as devolu��es em	um vetor din�mico do tamanho indicado pelo funcion�rio!
	O vetor din�mico deve ser criado dentro da fun��o main()!*/
	Biblioteca* ponteiro_Devolucoes = new Biblioteca[numero_Devolucoes + 1]; 
	cout << "Qual a data de devolu��o: ";
	cin >> data_Final.dia >> Lixo >> data_Final.mes >> Lixo >> data_Final.ano;
	funcao_Traco('-', 43);
	
	//O	programa deve rodar	em um la�o de repeti��o lendo cada uma das devolu��es previamente registradas em papel
	for (int i = 1; i <= numero_Devolucoes; i++) {
		cout << "\n"; cout << "Aluno"; cout.width(7); cout << ": ";
		
		cin >> ponteiro_Devolucoes[i].matricula;
		cout << "Livro"; cout.width(7); cout << ": ";
		cin >> ponteiro_Devolucoes[i].indentificador;
		cout << "Empr�stimo"; cout.width(1); cout << ": ";
		
		cin >> ponteiro_Devolucoes[i].data_Inicial.dia >> Lixo >> ponteiro_Devolucoes[i].data_Inicial.mes >> Lixo >> ponteiro_Devolucoes[i].data_Inicial.ano;
		cout << "Atraso"; cout.width(6); cout << ": ";
		cout << data_Final - ponteiro_Devolucoes[i].data_Inicial << " dia(s)\n";
		
		cout << "Multa"; cout.width(9); 
		cout << ": R$";
		cout.precision(2);
		/*O programa vai efetuar a subtra��o que foi estabelecida o no operator(-), sendo entre a data_Final e o ponteiro
		que irar apontar para cada data inicial armazenada e no final vai multiplicar por 0.80 que � o valor da multa!*/
		cout << fixed << (data_Final - ponteiro_Devolucoes[i].data_Inicial) * 0.80 << "\n";
		funcao_Traco('-', 33); 
	}	

	funcao_Traco('-', 10); cout << "\n\n";
	
	/*A principio vi que dava para simular um if usando varios la�os for, por�m n�o fiz isso por 2 motivos:
	01 - Iria deixar meu codigo muito extenso e provavelmente desorganizado
	02 - Vasculhando alguns laboratorios antigos vi que tinha uma atividade que fazia o uso da const char, ent�o vi que
	dava para mostrar a data por extenso usando ela.*/
	const char* mes[12] =
	{
		"janeiro", "fevereiro", "marco", "abril", "maio", "junho", "julho", "agosto", "setembro", "outubro", "novembro", "dezembro"
	};
	cout << "Resumo do dia " << data_Final.dia << " de "; cout << mes[data_Final.mes - 1] << " de " << data_Final.ano << "\n\n";

	for (int i = 1; i <= numero_Devolucoes; i++) {
		funcao_Resumo(ponteiro_Devolucoes[i], data_Final);
	}
	cout << "\n";

	funcao_Total(ponteiro_Devolucoes, data_Final, numero_Devolucoes);

	delete[] ponteiro_Devolucoes; //Para liberar a memoria usada pelo ponteiro_Devolucoes
}