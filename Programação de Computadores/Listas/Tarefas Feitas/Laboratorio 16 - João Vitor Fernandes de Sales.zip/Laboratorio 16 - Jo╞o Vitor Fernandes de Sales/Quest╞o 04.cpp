#include<iostream>
using namespace std;

int main() {
	//ESSE FOI O VETOR J� DECLARADO NA QUEST�O E INICIALIZADO COM 10 NUMEROS DIFERENTES

	int vetB[10] = {32, 16, 47, 10, 82, 29, 30, 28, 15, 64};

	/*NO PADR�O EXIGIDO PELA QUEST�O NOTAMOS QUE O PRIMEIRO VALOR SE CASA COM O ULTIMO VALOR
	E ISSO VAI DECRESCENDO, LOGO O PADRAO SERIA, SE FOR USAR A ESTRUTURA "FOR", CONSIDERAR QUE
	O PRIMEIRO VALOR � O CONTADOR E O ULTIMO � A ULTIMA POSI��O MENOS O CONTADOR*/
	//O PROGRAMA PEDE PARA N�O UTILIZAR PONTEIROS!

	for (int contador = 0; contador < 5; contador++) {
		cout << "[" << vetB[contador] << "," << vetB[9 - contador] << "]" << " ";
	}
}