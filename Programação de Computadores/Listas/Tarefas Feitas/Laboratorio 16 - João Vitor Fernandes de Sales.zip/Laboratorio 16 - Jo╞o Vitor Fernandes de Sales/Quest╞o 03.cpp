#include<iostream>
using namespace std;

int main() {
	//VETOR A J� INICIALIZADO COM 10 ELEMENTOS DO TIPO INTEIRO
	int vetA[10] = { 46, 78, 40, 96, 74, 58, 32, 56, 91, 6 };

	//DECLARA��O DOS PONTEIROS 1 E 2
	// O PONTEIRO 1 TEM QUE SEMPRE APONTAR
	int* ponteiro01;
	int * ponteiro02;
	ponteiro01 = vetA;
	ponteiro02 = vetA;
	int contador;
	for (contador = 0; contador < 5; contador++) {
		cout << "[" << ponteiro01[contador + contador] << "," << ponteiro02[contador + contador + 1] << "]" << " ";
	}
}