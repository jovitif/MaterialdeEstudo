#include<iostream>
using namespace std;

struct vetor_palavras {
	char palavras[15];
};

int main() {

	vetor_palavras* PALAVRA = new vetor_palavras[4];
	cout << "Digite 4 palavras: " << endl;

	for (int contador = 0; contador < 4; contador++) {
		cin >> PALAVRA[contador].palavras;
	}

	cout << "Concatenando as palavras obtem-se:" << endl;

	for (int contador = 0; contador < 4; contador++) {
		cout << PALAVRA[contador].palavras << " ";
	}
	delete[] PALAVRA;
}