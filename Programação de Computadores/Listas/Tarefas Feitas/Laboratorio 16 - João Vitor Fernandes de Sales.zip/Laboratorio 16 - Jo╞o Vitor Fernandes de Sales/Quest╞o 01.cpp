#include<iostream>
using namespace std;

/*
	Construa um programa que leia o nome de um jogador de futebol e seu respectivo 
time para um vetor de caracteres, como no exemplo abaixo. O nome do jogador e o 
nome do time sempre estar�o separados por uma barra e sem espa�os. Use um 
la�o for para localizar a posi��o do caractere '/' dentro do vetor e coloque um 
ponteiro apontando para o caractere seguinte. Mostre a quantidade de letras que 
tem o nome do jogador e, usando o ponteiro, mostre o nome do time.

Digite jogador/time: Pele/Santos
O nome do jogador tem 4 letras.
O seu time � o Santos.
*/

int main() {
	char jogadortime[30];
	char* ponteiro = new char[30];
	cout << "Digite jogador/time: ";
	cin >> jogadortime;
	int contador;
	for (contador = 0; jogadortime[contador] != '/'; contador++) {
	}
	cout << "O nome do jogador tem " << contador << " letras." << endl;
	ponteiro = &jogadortime[contador+1];
	cout << "O seu time e o " << ponteiro << ".";
}