#include<iostream>
using namespace std;

//Declare um registro Hor�rio com os campos horas e minutos.
struct horario {
	short hora, minuto;
};

void mostrar_resultado(short* pont, char pts, short min);

int main() {
	horario time;
	char pontos;
	short* ponteiro;
	ponteiro = &time.hora;

	cout << "Que horas sao: ";
	cin >> time.hora >> pontos >> time.minuto;
	//*ponteiro = *ponteiro + 1;
	//cout << "Seu relogio esta atrasado, o horario correto e " << time.hora << pontos << time.minuto;
	mostrar_resultado(ponteiro,pontos,time.minuto);
}

void mostrar_resultado(short* pont, char pts, short min) {
	*pont = *pont + 1;
	cout << "Seu relogio esta atrasado, o horario correto e " << *pont << pts << min;
}