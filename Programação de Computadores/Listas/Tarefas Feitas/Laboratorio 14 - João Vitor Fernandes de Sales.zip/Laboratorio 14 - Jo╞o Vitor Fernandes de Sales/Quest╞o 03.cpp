#include <iostream>
using namespace std;
int main()
{
	int valor = 10, * temp, soma = 0;
	temp = &valor;
	*temp = 20;
	temp = &soma;
	*temp = valor;
	cout << "valor: " << valor << "\nsoma: " << soma << endl;
}//Vendo atrav�s do depurador analisamos que a principio *temp = 10, por receber o valor da variavel valor que � 10//Al�m disso, soma recebe = 0 e valor = 10//Depois o ponteiro *temp � alterado para 20, soma continua = 0 e valor recebe 20, por causa da rela��o entre //O ponteiro e a variavel valor//Apos isso, o *temp recebe 0, por causa da associa��o com a variavel soma//Como o valor foi alterado de 10 para 20 e o *temp est� apontando novamente para a variavel, logo o valor e soma ser�o iguais