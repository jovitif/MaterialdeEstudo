#include<iostream>
using namespace std;

/*Declare um registro "Tigela" com os campos estado (cheia ou vazia) e tipo de 
alimento (sopa ou canja).
~Por ser somente dois tipos de estado e alimento, ent�o vou dizer que as variaveis estado e alimento s�o do tipo booleano.
*/

struct Tigela {
	string estado, alimento;
}valores;

/*
 Crie uma fun��o "Fome" que recebe um ponteiro para
uma Tigela e altera o seu estado para "vazia".
*/

/*Crie uma fun��o "Fome" que recebe um ponteiro para 
uma Tigela e altera o seu estado para "vazia".*/
void funcao_fome(string *pont, string val);

void exibir_inicio() {
	cout << "Seja bem-vindo(a) ao restaurante universitario (RU)..." << endl << endl;
	cout << "Digite aqui o seu nome: ";
}

/*Na fun��o principal crie uma tigela 
cheia, crie um ponteiro que aponta para essa tigela e ent�o mostre como a tigela 
estava antes da janta.*/
int main() {
	char nome[50];
	exibir_inicio();
	cin.getline(nome, 50);
	cout << "Ola " << nome << " o que voce deseja comer: " << endl;
	cout << "Deseja comer uma canja ou uma sopa ? " << endl;
	cin >> valores.alimento;

	if (valores.alimento == "canja" || valores.alimento == "Canja") {
		valores.estado = "cheia";
		string* ponteiro;
		ponteiro = &valores.estado;
		cout << "Esta na hora da janta uma canjinha e a sua tigela esta " << *ponteiro << endl;
		funcao_fome(ponteiro, valores.estado);
	}
	else if (valores.alimento == "sopa" || valores.alimento == "Sopa") {
		valores.estado = "cheia";
		string* ponteiro;
		ponteiro = &valores.estado;
		cout << "Esta na hora da janta uma sopinha e a sua tigela esta " << *ponteiro << endl;
		funcao_fome(ponteiro, valores.estado);
	}
	else {
		cout << "Sua opcao nao esta disponivel no cardapio universitario";
	}
}

/*Depois chame a fun��o Fome com o ponteiro que aponta 
para a tigela e ao fim mostre a tigela depois da janta.
*/

/*Crie uma fun��o "Fome" que recebe um ponteiro para 
uma Tigela e altera o seu estado para "vazia".*/
void funcao_fome(string* pont, string val) {
	pont = &val;
	*pont = "vazia";
	cout << "Agora a sua tigela esta " << val;
}