#include<iostream>
using namespace std;

/*Crie um registro Imagem que contenha campos para nome, altura, largura e tipo*/
struct Imagem {
	string nome, tipo;
	short altura, largura;
};

void funcao_detalhe(Imagem var);


int main() {
	/*No programa principal inicialize uma vari�vel do 
tipo Imagem e passe seu endere�o para uma fun��o Detalhes.*/
	Imagem variavel;
	/*o tipo um dos seguintes valores: JPG, PNG ou BMP. Use uma enumera��o 
para guardar o tipo da imagem.*/
	enum tip {JPG,PNG,BMP};
	tip num;
	num = PNG;
	/*No programa principal inicialize uma vari�vel do 
tipo Imagem e passe seu endere�o para uma fun��o Detalhes.*/
	variavel.nome = "backg";
	variavel.tipo = "png";
	variavel.altura = 1920;
	variavel.largura = 1080;
	funcao_detalhe(variavel);
}

void funcao_detalhe(Imagem var) {
	Imagem *pont = &var;
	cout << "A imagem ''"<< pont->nome << "." << pont->tipo << "'' com tamanho " << pont->altura << "x" << pont->largura << " tem formato " << pont->tipo << ".";
}