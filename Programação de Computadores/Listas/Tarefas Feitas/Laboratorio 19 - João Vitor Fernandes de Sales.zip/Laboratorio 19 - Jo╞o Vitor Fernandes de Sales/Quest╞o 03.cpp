#include<iostream>
using namespace std;

int main() {
	int mat[2][3] =
	{
	 {1,2,3},
	 {4,5,6}
	};

	cout << mat[0][0] << endl; //Como vai est� acessando o primeiro elemento da primeiro vetor, logo sera apresentado o 1.
	cout << mat[0] << endl; //Quando n�o � apontado o elemento do vetor, logo � apresentado o endere�o da linha.
	cout << &mat[0][0] << endl; //Est� acessando o endere�o de memoria do primeiro elemento da matriz.


}