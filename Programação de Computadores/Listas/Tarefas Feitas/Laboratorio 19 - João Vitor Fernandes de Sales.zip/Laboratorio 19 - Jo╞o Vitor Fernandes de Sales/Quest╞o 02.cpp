#include<iostream>
using namespace std;

/*
	 Voc� est� vendendo o livro �C++ s� do bom�. Escreva um programa que use um 
	vetor bidimensional para armazenar o n�mero de livros vendidos mensalmente 
	durante tr�s anos. 
	 O programa deve usar um la�o para perguntar sobre o n�mero de vendas de cada 
	m�s, exibindo o nome do m�s (use um vetor de const char * inicializado para os 
	nomes dos meses). Mostre o total de vendas em cada ano e o total geral dos tr�s 
	anos.
*/

int main() {
	/*
		Vamos supor que sejam 3 anos e que cada ano fosse ter vendido uma quantidade a cada mes, ent�o fica int vet[3][12]
		O la�o for deve rodar primeiro os anos e como
	*/

	//const char* sera para enumerar cada mes do ano!
	const char* meses[12] = {"janeiro", "fevereiro", "mar�o", "abril", "maio", "junho", "julho", "agosto", "setembro", "outubro", "novembro", "dezembro"};
	int vetorlivro[3][12];
	for (int anos=0; anos <= 2; anos++) {
		cout << "Digite o n�mero de livros vendidos no " << anos << "� ano:" << endl;
		for (int mes = 0; mes <= 11; mes++) {
			cout << meses[mes] << ": ";
			cin >> vetorlivro[anos][mes];
		}
		cout << endl;
	}
	
	cout << "Total de vendas: " << endl;
	int soma1 = 0;
	int* ponteiro = &soma1;
	for (int s = 0; s <= 2; s++) {
		soma1 = 0;
		for (int c = 0; c <= 11; c++) {
			soma1 = soma1 + vetorlivro[s][c];
		}
		cout << "Ano " << s << ":" << soma1 << endl;
	}

	cout << "Nos tr�s anos foram vendidos " << soma1 << " livros";


}