#include<iostream>
using namespace std;

int main() {
	/*
		Foi criada a matriz com 3 linhas e 3 colunas, para fazer o teste, e como na Matriz[0] ta acessando
		so o endere�o do primeiro vetor, logo irar mostrar somente o endere�o!
		Com o vetor ocorre diferente, porque ele j� especifica qual elemente que sera usado para imprimir na tela!
	*/

	int matriz[3][3] = {
		{3, 4, 5},
		{4, 5, 6},
		{3, 2, 1}
	};
	int vetor[3] = { 12,10,11 };

	cout << matriz[0] << endl;
	cout << vetor[0];
}