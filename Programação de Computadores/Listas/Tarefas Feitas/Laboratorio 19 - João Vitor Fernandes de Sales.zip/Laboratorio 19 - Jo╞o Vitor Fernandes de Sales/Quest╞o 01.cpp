#include<iostream>
using namespace std;

/*
Escreva um programa que utilize la�os for aninhados para calcular e mostrar a
soma das colunas de um vetor bidimensional 4x4, como mostrado no exemplo
abaixo. A matriz deve ser inicializada no momento da sua declara��o.
*/

int main() {

	//Declara��o da matriz apresentada na quest�o 01. Uma matriz � varios vetores!
	int matriz[4][4] = {
		{3, 1, 5, 5},
		{1, 5, 5, 6},
		{2, 3, 4, 5},
		{4, 9, 1, 8}
	};

	//Criei a variavel soma e inicializei com 0, pois ela sera usada como base para realizar a soma de todas as linhas das colunas
	int soma=0;
	cout << "A soma das colunas e: ";

	/*
		Usando a logica devemos acessar primeiro a coluna e depois a linha para ai sim realizar as somas!
		Assim, o programa vai acessar a primeira coluna e assim sucessivamente at� chegar na ultima coluna que � o 
		Matriz[linha][3]!
		A linha sera acessada apos ir na primeira coluna e ira realizar a soma dos 4 termos da linha
	*/

	for (int coluna = 0; coluna <= 3; coluna++) {
		for (int linha = 0; linha <= 3; linha++) {
			soma = soma + matriz[linha][coluna];
		}
		cout << soma << " ";
		soma = 0;
	}

}