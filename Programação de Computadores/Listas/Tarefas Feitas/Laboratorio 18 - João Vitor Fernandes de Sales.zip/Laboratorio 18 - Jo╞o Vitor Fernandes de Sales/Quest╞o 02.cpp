#include<iostream>
using namespace std;

int main() {
	//Usando o la�o for:
	int somatorio = 0;
	cout << "O somatorio dos numeros impares usando o LACO FOR fica:";
	for (int contador = 1; contador <= 100; contador = contador + 2) {
		somatorio = somatorio + contador;
	}
	cout << somatorio;
	cout << endl << endl;

	//Usando o la�o while:
	cout << "O somatorio dos numeros impares usando o LACO WHILE fica:";
	int contador = 1;
	int somatorio1 = 0;
	while (contador <= 100) {
		somatorio1 = somatorio1 + contador;
		contador = contador + 2;
	}
	cout << somatorio;
	cout << endl << endl;

	//Usando o la�o do while:
	int contador2 = 1;
	int somatorio2 = 0;
	cout << "Os numeros digitados usando o LACO DO WHILE fica:";
	do {
		somatorio2 = somatorio2 + contador2;
		contador2 = contador2 + 2;
	}while(contador2 <= 100);
	cout << somatorio;
	cout << endl << endl;
}