#include<iostream>
using namespace std;

int main() {
	int vet_num[100];
	cout << "Digite as idades do grupo:" << endl;
	int cont1 = 0;
	do {
		cont1++;
		cin >> vet_num[cont1];
	} while (vet_num[cont1] != 0);

	int cont = 0;
	int cont2 = 0;

	cout << "Nesse grupo ";
	while (cont <= cont1) {
		if (vet_num[cont] >= 18) {
			cont2 = cont2 + 1;
		}
		else {
		}
		cont++;
	}
	cout << cont2 << " pessoas sao maiores de idade.";
}