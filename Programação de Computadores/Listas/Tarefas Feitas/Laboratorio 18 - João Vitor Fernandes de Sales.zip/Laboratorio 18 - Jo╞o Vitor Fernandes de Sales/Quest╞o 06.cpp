#include<iostream>
#include<cstring>
using namespace std;

struct Pessoa {
	char nome[30];
	short idade;
	char sexo[10];
};

int main() {
	cout << "CADASTRO NOME, IDADE E SEXO" << endl;
	int quantidade = 0;
	Pessoa* vet = new Pessoa;
		while (strcmp(vet->nome, "fim")) {
			cout << "NOME:";
			cin >> vet->nome;
			cout << "IDADE:";
			cin >> vet[quantidade].idade;
			cout << "SEXO:";
			cin >> vet->sexo;
			quantidade = quantidade + 1;
		}
		int y = (quantidade-1);
		cout << "A quantidade de pessoas armazenadas foram: " << y;
	
		float soma=0.0;
		for (int i = 0; i <= y; i++) {
			soma = vet[i].idade + soma;
		}
		float x = (soma/y);
		cout << endl;
		cout << "A media das idades e: " << x;
}