#include<iostream>
using namespace std;

int main() {
	int i = 0;
	while (++i < 4)
		cout << "Oi! ";
	do
		cout << "Tchau! ";
	while (i++ <= 8);

}

/*
	Ele ira imprimir o "Oi! " 3 x primeiro, pois o contador est� incrementando um j� no inicio do teste
	Ap�s isso ele ira realizar o do while irar imprimimr na tela o "Tchau! " 6 x
*/