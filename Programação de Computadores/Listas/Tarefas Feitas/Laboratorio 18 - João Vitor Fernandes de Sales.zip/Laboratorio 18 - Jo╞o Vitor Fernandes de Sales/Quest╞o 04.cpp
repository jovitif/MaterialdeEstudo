#include<iostream>
#include<cstring>
using namespace std;

int main() {
	cout << "Entre com uma frase que eu verei se e um palindro:";
	char texto[] = "anotaram a data da maratona";

	cout << texto << endl;
	char temp;
	int i=strlen(texto)-1, j = 0;

	cout << "Sua frase invertida fica:";
	while (j<i) {
		temp = texto[i];
		texto[i] = texto[j];
		texto[j] = temp;
		--i;
		++j;
	}
	cout << texto << endl;


	if (texto[i] != texto[j]) {
		cout << "Sua frase NAO se trata de um palindro!";
	}else{
		cout << "Sua frase e um palindro!";
	}
}