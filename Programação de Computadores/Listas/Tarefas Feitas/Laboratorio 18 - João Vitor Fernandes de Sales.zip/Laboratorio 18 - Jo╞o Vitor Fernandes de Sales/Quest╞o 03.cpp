#include <iostream>
using namespace std;

int main() {
	char texto[1000];
	cout << "Digite um texto:";
	cin.getline(texto, 1000);
	int cont = 0;
	while (texto[cont] != '@') {
		cout << texto[cont];
		cont++;
	}
}