#include <iostream>
using namespace std;
int main() 
{
	double variavel = 245.795;
	int resultado = int(variavel);
	cout << "O resultado e: " << resultado << endl;
	cout << variavel * 100 << endl;
	cout << resultado * 100 << endl;
}
/*A li��o que podemos tirar � que ao multiplicar um numero sendo double ou sendo um int o resultado irar ser
totalmente diferente, pois ambos s�o na passagem do double para o int ocorre uma convers�o for�ada*/