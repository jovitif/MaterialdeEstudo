#include<iostream>
using namespace std;
int main()
{

	cout << "Digite um numero real: ";
	float numero;
	cin >> numero;
	int y = int(numero * 100000);

	cout << "A parte inteira: " << y / 100000 << endl;
	cout << "A parte fracionada: " << y % 100000 << endl;
}