#include <iostream>
using namespace std;
int main() 
{
	cout << "Digite dois numeros inteiros: ";
	int numero_01, numero_02;
	cin >> numero_01 >> numero_02;
	int quociente = numero_01 / numero_02;
	int resto = numero_01 % numero_02;
	cout << "O quociente " << numero_01 << "/" << numero_02 << " e " << quociente << endl;
	cout << "O resta da divisao " << numero_01 << "%" << numero_02 <<" e " << resto << endl;


}