#include <iostream>
using namespace std;
int main() 
{
	//Declara��o da constante de convers�o de medidas:
	//Como um Kilometro tem 1000 metros, ent�o esse sera o valor utilizado
	const int conversao = 1000;
	int valor_metro;
	//O usuario ira digitar a distancia em metros
	cout << "Entre com a distancia em metros: ";
	cin >> valor_metro;

	int valor_km = valor_metro / conversao;
	int valor_m = valor_metro % conversao;

	cout << valor_metro << " metros equivalem a " << valor_km << " quilometros e " << valor_m << " metros";
}