#include <iostream>
using namespace std;

int main() 
{
	int a, b, c;
	a = 1 + 2; // linha 1
	b = 1 + a; // linha 2
	c = 1 % 5; // linha 3
	a = a + 2; // linha 4
	b = a - c; // linha 5
	b = 5 * c / 2; // linha 6

}

//Ao iniciar a depura��o passo a passo temos o seguinte:
//Linha 1 a = 3, b = 0, c = 570
//Linha 2 a = 3, b = 4, c = 570
//Linha 3 a = 3, b = 4 
//Linha 4 a = 5, b = 4, c = 1
//Linha 5 a = 5, c = 1
//Linha 6 a = 5, b = 2 e c=1