#include <iostream>                              //  Inclus�o das bibliotecas necessarias
#include<iomanip>

using namespace std;

unsigned int funcao_Armazena(unsigned char, unsigned char, unsigned char, unsigned char);     //   Todos os prototipos das fun��es
unsigned int soma_32bits(unsigned int, unsigned int);
unsigned int multi_32bits(unsigned int, unsigned int);
unsigned int funcao_soma(unsigned int, unsigned int);
unsigned int funcao_multiplicacao(unsigned int, unsigned int);

int main()
{
	unsigned int n1, n2, n3, n4;    //o primeiro passo � colocar os primeiros 4 valores em um �nico bloco de mem�ria(xxma).
	unsigned int n5, n6, n7, n8;    //os outros 4 valores em um outro bloco (xxmb).
	char lixo, lixo2;      //Variaveis lixos somente de enfeite para o programa

	cin >> lixo >> n1 >> lixo2 >> n2 >> lixo2 >> n3 >> lixo2 >> n4 >> lixo;   //8 valores lidos do usu�rio
	cin >> lixo >> n5 >> lixo2 >> n6 >> lixo2 >> n7 >> lixo2 >> n8 >> lixo;
	cout << " " << endl;

	cout << "Operandos em 32 bits = " << funcao_Armazena(n1, n2, n3, n4) << endl;
	cout << "Operandos em 32 bits = " << funcao_Armazena(n5, n6, n7, n8) << endl;
	cout << " " << endl;

	cout << "Soma em 32 bits = " << soma_32bits(funcao_Armazena(n1, n2, n3, n4), funcao_Armazena(n5, n6, n7, n8)) << endl;
	cout << "Multi em 32 bits = " << multi_32bits(funcao_Armazena(n1, n2, n3, n4), funcao_Armazena(n5, n6, n7, n8)) << endl;
	cout << " " << endl;

	cout << "[" << setw(3) << setfill('0') << funcao_soma(n1, n5) << "," << setw(3) << setfill('0') << funcao_soma(n2, n6) << "," << setw(3) << setfill('0') << funcao_soma(n3, n7) << "," << setw(3) << setfill('0') << funcao_soma(n4, n8) << "] = Somas" << endl;
	cout << "[" << setw(3) << setfill('0') << funcao_multiplicacao(n1, n5) << "," << setw(3) << setfill('0') << funcao_multiplicacao(n2, n6) << "," << setw(3) << setfill('0') << funcao_multiplicacao(n3, n7) << "," << setw(3) << setfill('0') << funcao_multiplicacao(n4, n8) << "] = Multiplicacao" << endl;
}

unsigned int funcao_soma(unsigned int a, unsigned int b) {                //Defini��o de cada uma das fun��es necessarias
	unsigned int resultado_soma = (a + b);
	return resultado_soma;
}

unsigned int funcao_multiplicacao(unsigned int a, unsigned int b) {
	unsigned int resultado_multiplicacao = a * b;
	return resultado_multiplicacao;
}

unsigned int funcao_Armazena(unsigned char x1, unsigned char x2, unsigned char x3, unsigned char x4) {
	unsigned int valor_armazenar = (x1 << 24) | (x2 << 16) | (x3 << 8) | x4;
	return valor_armazenar;
}

unsigned int soma_32bits(unsigned int x, unsigned int y) {
	unsigned int somabits = x + y;
	return somabits;
}

unsigned int multi_32bits(unsigned int v1, unsigned int v2) {
	unsigned int multiplicacoes = (v1<<8) * (v2<<8);
	return multiplicacoes;
}