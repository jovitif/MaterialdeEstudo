#include <iostream>
#include <cstring>

using namespace std;

struct Login {
    char nome[100];
    char senha[100];
};

int main() {

    Login login = { "joaozinho" , "joaozinho1234" };
    Login usuario{};

    cout << "Digite seu login: ";
    cin >> usuario.nome;

    cout << "Digite sua senha: ";
    cin >> usuario.senha;


    bool administrador = false;

    int administradorNomeTamanho = strlen(login.nome);
    int administradorSenhaTamanho = strlen(login.senha);


    int count = 0;
    for (int i = 0; i <= strlen(usuario.nome); i++) {
        if (login.nome[i] == usuario.nome[i])
            count++;
    }

    int count1 = 0;
    for (int i = 0; i <= strlen(usuario.senha); i++) {
        if (login.senha[i] == usuario.senha[i])
            count1++;
    }

    if ((count == administradorNomeTamanho) && (count1 == administradorSenhaTamanho)) {
        administrador = true;
    }

    if (administrador) {
        cout << "Login e senha corretos";
    }
    else {
        cout << "Login e senha incorretos";
    }



}