#include<iostream>
using namespace std;

int main() {
	cout << "Digite 10 valores: ";
	int vetorA[5], vetorB[5], vetorSoma[5];
	for (int contador = 0; contador < 5; contador++) {
		cin >> vetorA[contador];
	}
	for (int contador = 0; contador < 5; contador++) {
		cin >> vetorB[contador];
	}
	cout << "Vetor A: ";
	for (int contador = 0; contador < 5; contador++) {
		cout << vetorA[contador] << " ";
	}
	cout << endl;
	cout << "Vetor B: ";
	for (int contador = 0; contador < 5; contador++) {
		cout << vetorB[contador] << " ";
	}
	cout << endl;
	cout << "Vetor S: ";
	for (int contador = 0; contador < 5; contador++) {
		cout << vetorA[contador] + vetorB[contador] << " ";
	}
	cout << endl;
}