#include<iostream>
#include<cmath>
using namespace std;

int main() {
	cout << "A soma dos quadrados dos 100 primeiros numeros naturais e: ";
	int x = 0;

	for (int contador = 1; contador <= 100; contador++) {
		x = x + pow(contador, 2);
	}
	cout << x << endl;

	cout << "O quadrado da soma dos 100 primeiros numeros naturais e: ";
	int y = 0;

	for (int contador = 1; contador <= 100; contador++) {
		y = y + contador;
	}
	y = pow(y, 2);
	cout << y << endl;

	cout << "a diferen�a entre a soma dos quadrados dos 100 primeiros numeros naturais e o quadrado da soma e: ";
	cout << y - x;

}