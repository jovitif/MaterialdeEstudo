#include<iostream>
using namespace std;

int main() {
	cout << "Voce quer que eu conte de 1 ate que numero? ";
	int numero;
	cin >> numero;
	for (int contador = 1; contador <= numero; contador++) {
		cout << contador << " ";
	}
	cout << endl;
	for (int contador = 0; contador <= numero-1; contador++) {
		cout << numero - contador << " ";
	}
	cout << endl;
	for (int contador = 1; contador <= numero; contador = contador + 2) {
		cout << contador << " ";
	}
	cout << endl;
	for (int contador = 1; contador <= numero; contador=contador+2) {
		cout << numero - contador << " ";
	}
	cout << endl;
	for (int contador = 0; contador < numero; contador = contador + 2) {
		cout << contador + 2 << " ";
	}
	cout << endl;
	for (int contador = 0; contador <= numero-1; contador = contador + 2) {
		cout << numero - contador << " ";
	}
	cout << endl;
}