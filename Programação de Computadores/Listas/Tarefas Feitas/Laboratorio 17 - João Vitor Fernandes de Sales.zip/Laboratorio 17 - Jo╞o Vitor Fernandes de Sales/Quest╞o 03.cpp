#include<iostream>
using namespace std;

void funcao_numeros(int a, int b);

int main() {
	int numero1, numero2;
	cout << "Digite o inicio:";
	cin >> numero1;
	cout << "Digite o fim:";
	cin >> numero2;
	funcao_numeros(numero1, numero2);
}

void funcao_numeros(int a, int b) {
	int contador;
	int x = 0;
	for (contador = a; contador <= b; contador++) {
		x = x + (contador);
	}
	cout << x;
}