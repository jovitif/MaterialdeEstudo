#include<iostream>
using namespace std;

//Cria��o do registro Local que recebe 3 char
struct Local {
	char nome[30], pais[30], continente[30];
};

int main() {
	cout << "----------------SEJA BEM VINDO A SUA EMPRESA DE VIAGEM VOA.NET---------------------" << endl << endl;
	cout << "Quantos locais voce deseja visitar nas ferias ?:";
	int quantidade; //pergunta a quantidade de locais que deseja visitar
	cin >> quantidade;
	cout << " " << endl << endl;
	Local* vetor_Local = new Local[quantidade];

	//La�o de repeti��o for
	for (int contador = 0; contador < quantidade; contador++) {
	cout << "Local numero: " << contador + 1 << endl;
	cin.get();
	cout << "Qual continente voce deseja visitar ?:\n"; cin.getline(vetor_Local[contador].continente,30);
	//cin.get();
	cout << "Qual pais voce deseja visitar ?:\n"; cin.getline(vetor_Local[contador].pais,30);
	//cin.get();
	cout << "Qual local voce deseja visitar ?:\n"; cin.getline(vetor_Local[contador].nome,30);
	//cin.get();
	cout << " " << endl << endl;
}
	//La�o de repeti��o for 2
	for (int contador = 0; contador < quantidade; contador++) {
		cout << "Continente visitado: " << vetor_Local[contador].continente << endl;
		cout << "Pais visitado: " << vetor_Local[contador].pais << endl;
		cout << "Local visitado: " << vetor_Local[contador].nome << endl;
		cout << "" << endl << endl;

	}
	//Apos usar o ponteiro para deslocar dinamicamente um valor na memoria eu tenho que dar um delete nele
	//com a finalidade de liberar espa�o na memoria
	delete[] vetor_Local;
}

//Relatorio: Uma coisa que eu estava errando muito no programa era na hora de armazenar as informa��es, porque enchia de cin.get() sem necessidade, o que dificultou no desenvolvimento do programa.