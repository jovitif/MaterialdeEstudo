#include<iostream>
using namespace std;

int main() {
	int* ponteiro = new int; //Declare um ponteiro para inteiro, aloque mem�ria dinamicamente para ele e armazene o n�mero 100 nessa mem�ria.
	*ponteiro = 100;
	cout << "Conteudo armazenado: " << *ponteiro << endl; //Mostre o conte�do apontado.
	delete ponteiro;
	ponteiro = new int;
	cout << "Digite novo valor para esse bloco de memoria: "; //Pe�a que o usu�rio digite um novo n�mero inteiro
	cin >> *ponteiro;
	cout << "Conteudo armazenado: " << *ponteiro; //armazene-o na mem�ria previamente alocada
	delete ponteiro; //Libere o espa�o alocado dinamicamente ao final do programa
}