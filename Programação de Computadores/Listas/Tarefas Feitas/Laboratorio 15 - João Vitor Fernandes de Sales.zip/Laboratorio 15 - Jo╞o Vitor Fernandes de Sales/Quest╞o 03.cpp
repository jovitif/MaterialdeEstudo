#include<iostream>
using namespace std;

int main(){
	//Inicie o programa perguntando ao usu�rio quantos inteiros ele deseja armazenar em um vetor
	cout << "Quantos valores deseja guardar? ";
	int variavel_digitada;
	cin >> variavel_digitada;
	// Use a informa��o digitada para criar um vetor din�mico com o espa�o necess�rio para armazenar a quantidade de inteiros desejada.
	
	int* vetor_dinamico = new int[variavel_digitada];
	/*Depois disso, 
	deixe que o pr�prio usu�rio preencha o vetor, utilizando o tamanho do vetor como 
	condi��o de parada de um la�o for*/

	cout << "Quais os valores? ";
	for (int contador = 0; contador < variavel_digitada; contador++) {
		cin >> vetor_dinamico[contador];
	}
	
	cout << "Os valores digitados ";
	for (int contador2 = 0; contador2 < variavel_digitada-1; contador2++) {
		if (contador2 < variavel_digitada - 2) {
		cout << vetor_dinamico[contador2] << ", ";
		}
		else {
			cout << vetor_dinamico[contador2] << " e " << vetor_dinamico[contador2+1];
		}
	}
	cout << " foram armazenados.";
	/* Mostre o vetor que foi preenchido atrav�s de 
	outro la�o e libere o espa�o alocado dinamicamente ao final do programa*/
	delete[]vetor_dinamico;
}

/*

	A dificuldade dessa quest�o estava em principalmente mostrar na tela os valores exatos e com o "e" antes e depois do ultimo e 
	penultino numero, ent�o al�m do la�o for, tive que usar uma estrutura condicional que julgava se o valor era maior que a variavel
	do ultimo e antepenultimo
*/