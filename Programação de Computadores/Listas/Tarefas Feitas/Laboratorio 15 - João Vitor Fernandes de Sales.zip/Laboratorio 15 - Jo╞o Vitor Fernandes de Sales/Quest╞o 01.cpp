#include<iostream>
using namespace std;

int main() {
	float peso;
	peso = 30;
	cout << peso;
	delete peso;
}

/*

	Resposta: N�o. O programa resulta em erro, porque n�o � possiv�l deletar uma variavel estatica da memoria, sendo algo possivel somente
	por meio do uso de um ponteiro para se alocar uma nova memoria dinamica, assim podendo mudar o valor das variaveis independente do 
	tipo

*/

/*

	Uma poss�vel adapta��o para a variaver ser deletada, seria mudar todo o programa, criando um ponteiro e o resultado final seria:
	float* peso = new float;
	*peso = 30;
	cout << *peso;
	delete peso;

*/