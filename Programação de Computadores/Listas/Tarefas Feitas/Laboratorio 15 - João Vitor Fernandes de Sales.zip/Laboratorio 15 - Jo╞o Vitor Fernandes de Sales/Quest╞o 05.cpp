#include<iostream>
using namespace std;

//Cria��o do registro ASCII
struct ASCII {
	char caractere;
	int inteiro;
}exemplo;

void funcao_RECEBA(char carac, int inter, char *pont1 = new char, int *pont2 = new int) { //Cria��o da funcao_RECEBA
	cout << "Digite um caractere: ";
	cin >> carac;
	pont1 = &carac;
	cout << "Digite um valor inteiro: ";
	cin >> inter;
	pont2 = &inter;
	cout << "O endereco do seu caractere e: " << &pont1 << endl;
	cout << "O endereco do seu inteiro e: " << pont2 << endl;
}

int main() {
	char* ponteiro1 = new char;
	int* ponteiro2 = new int;
	funcao_RECEBA(exemplo.caractere,exemplo.inteiro,ponteiro1,ponteiro2);
	delete ponteiro1;
	delete ponteiro2;
}