#include<iostream>
using namespace std;

struct Nadador {
	char name[30];
	short age;
	char cat[12];
};
const char * categorias[5] = {"Infantil", "Juvenil", "Adolescente", "Adulto", "S�nior"};
int main() {
	Nadador nad01;
	cout << "Digite o nome do nadador: ";
	cin >> nad01.name;
	cout << "Digite a idade do nadador: ";
	cin >> nad01.age;
	if (nad01.age < 5) {
		cout << "Idade muito abaixo do esperado!";
	}
	else if (nad01.age >= 5 && nad01.age <= 7) {
		cout << categorias[0];
	}
	else if (nad01.age >= 8 && nad01.age <= 10) {
		cout << categorias[1];
	}
	else if (nad01.age >= 11 && nad01.age < 15) {
		cout << categorias[2];
	}
	else if (nad01.age >= 15 && nad01.age <= 30) {
		cout << categorias[3];
	}
	else {
		cout << categorias[4];
	}
}