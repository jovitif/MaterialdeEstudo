#include<iostream>
#include<locale.h>
using namespace std;

int main() {
	setlocale(LC_ALL, "portuguese");
	long long num1 = 1, num2 = 1, antig, quant, sum=0;
	cout << "Sequ�ncia de Fibonacci: ";
	cin >> quant;
	if (quant >= 3) {
		for (int i = 0; i <= quant - 1; i++) {
			if (num2 % 2 == 0) {
				sum = sum + num2;
			}
			cout << num2 << " ";
			antig = num2;
			num2 = num2 + num1;
			num1 = antig;
		}
	}
	cout << "\nSoma de todos os termos pares e " << sum;
}