#include<iostream>
using namespace std;
#include<locale.h>

int main() {
	setlocale(LC_ALL, "portuguese");
	  long long sum = 0;
	 long long  num = 0;
	 long long total = 0;
	 long long quant;
	cout << "Qual posi��o deseja ver ?: ";
	cin >> quant;
		while (total < quant) {
			sum = 0;
			for ( long long i = 1; i <= num; i++) {
				if (num % i == 0) {
					sum = sum + 1;

				}
				else {}
			}
			if (sum == 2) {
			//	cout << num << " ";
				total++;
			}
			else {
			}
			num++;
		}
		cout << "O ultimo numero primo lista � " << num - 1;
}