#include<iostream>
using namespace std;

/*
	2520 � o menor n�mero que pode ser dividido por cada um dos n�meros de 1 a 10 
	sem deixar resto. Qual � o menor n�mero positivo que � divis�vel por todos os 
	n�meros de 1 a 20 sem deixar resto?
*/

int main() {
	int total;
	const int num = 2520;
	for (short i = 1; i <= 20; i++) {
		if (num % i != 0) {
			cout << "O numero " << i << " deixa resto!\n";
		}
		else {
		}
	}
}