#include<iostream>
using namespace std;

int main() {
	int sum = 0;
	short num, i = 1;
	while (i < 1000) {
		num = i;
		if (num % 3 == 0 || num % 5 ==0) {
			sum = num + sum;
		}
		i++;
	}
	cout << "Somatorio: " << sum;
}