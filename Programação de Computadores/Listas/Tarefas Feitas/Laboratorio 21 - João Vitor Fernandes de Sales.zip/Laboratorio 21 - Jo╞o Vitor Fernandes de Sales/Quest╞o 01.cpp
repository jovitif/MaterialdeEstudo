#include<iostream>
using namespace std;
/*
	1. Construa express�es l�gicas para representar as seguintes condi��es:
		a. ch n�o � um q nem um k
		b. idade n�o est� entre 15 e 26
		c. x � impar e maior que 30
		d. num � m�ltiplo de 5 ou de 8
		e. peso n�o � menor que 50 e altura � maior que 160
*/
int main() {
	char ch;
	short idade, num, x, peso, altura;
	if (ch != 'q' && ch != 'k');
	if (!(idade >= 15 && idade <= 26));
	if (x % 2 != 0 && x > 30);
	if (num % 5 == 0 || num % 8 == 0);
	if (!(peso < 50) && altura > 160);
}