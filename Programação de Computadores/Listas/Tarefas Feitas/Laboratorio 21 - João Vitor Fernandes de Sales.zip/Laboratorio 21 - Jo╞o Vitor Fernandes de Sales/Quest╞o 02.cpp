#include<iostream>
using namespace std;
#include<locale.h>
/*
	Crie um programa que receba um n�mero inteiro maior que zero e determine se
	ele � um n�mero primo.
*/
int main() {
	setlocale(LC_ALL, "portuguese");
	short sum=0;
	short num;
	while (sum != 2) {
		sum = 0;
		cout << "Digite um numero: ";
		cin >> num;
		for (short i = 1; i <= num; i++) {
			if (num % i == 0) {
				sum = sum + 1;
			}
			else {}
		}
		if (sum == 2) {
			cout << num << " � um numero primo, pois ele � dividido por 1 e por " << num << ".\n";
		}
		else {
			cout << num << " n�o � um numero primo, pois ele possui " << sum << " divisores.\n";
		}
	}
}
