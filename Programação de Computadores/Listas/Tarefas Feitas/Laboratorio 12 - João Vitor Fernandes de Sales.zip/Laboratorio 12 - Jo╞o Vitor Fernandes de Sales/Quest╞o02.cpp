#include<iostream>
#include<string>
using namespace std;

struct palavra {
	string portugues;
	string ingles;
	string espanhol;
};

int main()
{
	palavra dicionario[10];
	dicionario[0] = {"Crianca","Nino","Child"};
	dicionario[1] = { "Filho","Son","Hijo" };

	cout << "Acabei de digitar 3 palavras em 3 idiomas e sao elas: " << endl;
	cout << dicionario[0].portugues << endl;
	cout << dicionario[0].ingles << endl;
	cout << dicionario[0].espanhol << endl;
	cout << "-----------------------------" << endl;
	cout << dicionario[1].portugues << endl;
	cout << dicionario[1].ingles << endl;
	cout << dicionario[1].espanhol << endl;
	cout << "Digite uma palavra em 3 idiomas, sendo portugues, ingles e espanhol: " << endl;
	cout << "portugues: ";
	cin >> dicionario[2].portugues;
	cout << "ingles: ";
	cin >> dicionario[2].ingles;
	cout << "espanhol: ";
	cin >> dicionario[2].espanhol;
	cout << "Digite outras 3 palavras: " << endl;
	cout << "portugues: ";
	cin >> dicionario[3].portugues;
	cout << "ingles: ";
	cin >> dicionario[3].ingles;
	cout << "espanhol: ";
	cin >> dicionario[3].espanhol;
	cout << "Todas as palavras do dicionario em seus 3 idiomas: " << endl;
	cout << "Palavras em portugues: " << dicionario[0].portugues << " " << dicionario[1].portugues << " " << dicionario[2].portugues << " " << dicionario[3].portugues << endl;
	cout << "Palavras em ingles: " << dicionario[0].ingles << " " << dicionario[1].ingles << " " << dicionario[2].ingles << " " << dicionario[3].ingles << endl;
	cout << "Palavras em espanhol: " << dicionario[0].espanhol << " " << dicionario[1].espanhol << " " << dicionario[2].espanhol << " " << dicionario[3].espanhol << endl;
}