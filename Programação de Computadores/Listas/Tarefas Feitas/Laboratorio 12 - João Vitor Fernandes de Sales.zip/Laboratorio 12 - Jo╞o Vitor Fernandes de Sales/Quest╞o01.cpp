//Conta Banc�ria
#include<iostream>
using namespace std;

struct contabancaria {
	char nome[40];
	unsigned saldo;
};

int main() 
{
	cout << "Seja bem vindo(a) ao seu registro bancario" << endl;
	cout << "------------------------------------------" << endl;
	cout << "Entre com o seu nome completo: ";
	contabancaria novacontabancaria;
	//cin >> novacontabancaria.nome;
	cin.getline(novacontabancaria.nome, 40);
	novacontabancaria.saldo = 0;
	cout << "Seja bem vindo " << novacontabancaria.nome << ". " << endl;
	cout << "Voce tem " << novacontabancaria.saldo << "R$ deseja acrescentar quanto ? ";
	cin >> novacontabancaria.saldo;
	cout << "Nome completo: " << novacontabancaria.nome << endl;
	cout << "Saldo atual: " << novacontabancaria.saldo << "R$.";
}