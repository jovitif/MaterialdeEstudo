#include<iostream>
#include<string>
using namespace std;

//Cria��o dos registros:

//Cria��o do registro contabancaria
struct contabancaria {
	char nome[40];
	unsigned saldo;

	void mostrar() {
		cout << "Nome completo: " << nome << endl;
		cout << "Saldo atual: " << saldo << "R$.";
	}
};

//Cria��o do registro palavra

struct palavra {
	string portugues;
	string ingles;
	string espanhol;

	void mostrar1() {
		cout << "Palavras em portugues: " << portugues << endl;
		cout << "Palavras em ingles: " << ingles << endl;
		cout << "Palavras em espanhol: " << espanhol << endl;
	}
};

void inserir() {
	cout << "Seja bem vindo(a) ao seu registro bancario" << endl;
	cout << "------------------------------------------" << endl;
	cout << "Entre com o seu nome completo: ";
}



int main()
{
	inserir();
	contabancaria novacontabancaria;
	cin.getline(novacontabancaria.nome, 40);
	novacontabancaria.saldo = 0;
	cout << "Seja bem vindo " << novacontabancaria.nome << ". " << endl;
	cout << "Voce tem " << novacontabancaria.saldo << "R$ deseja acrescentar quanto ? ";
	cin >> novacontabancaria.saldo;
	novacontabancaria.mostrar();

	//Quest�o 02
	palavra dicionario[10];
	dicionario[0] = { "Crianca","Nino","Child" };
	dicionario[1] = { "Filho","Son","Hijo" };

	cout << "Acabei de digitar 3 palavras em 3 idiomas e sao elas: " << endl;
	cout << dicionario[0].portugues << endl;
	cout << dicionario[0].ingles << endl;
	cout << dicionario[0].espanhol << endl;
	cout << "-----------------------------" << endl;
	cout << dicionario[1].portugues << endl;
	cout << dicionario[1].ingles << endl;
	cout << dicionario[1].espanhol << endl;
	cout << "Digite uma palavra em 3 idiomas, sendo portugues, ingles e espanhol: " << endl;
	cout << "portugues: ";
	cin >> dicionario[2].portugues;
	cout << "ingles: ";
	cin >> dicionario[2].ingles;
	cout << "espanhol: ";
	cin >> dicionario[2].espanhol;
	cout << "Digite outras 3 palavras: " << endl;
	cout << "portugues: ";
	cin >> dicionario[3].portugues;
	cout << "ingles: ";
	cin >> dicionario[3].ingles;
	cout << "espanhol: ";
	cin >> dicionario[3].espanhol;
	cout << "Todas as palavras do dicionario em seus 3 idiomas: " << endl;
	dicionario[0].mostrar1();
	dicionario[1].mostrar1();
	dicionario[2].mostrar1();
	dicionario[3].mostrar1();
}