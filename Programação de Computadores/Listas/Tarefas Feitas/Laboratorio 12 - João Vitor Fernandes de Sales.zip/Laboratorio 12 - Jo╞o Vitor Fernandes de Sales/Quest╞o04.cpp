#include<iostream>
#include<string>
using namespace std;

struct livro {
	string nome, genero;
	unsigned short valor;

	void inserir(string nom, string gen, unsigned short val) {
		nome = nom;
		genero = gen;
		valor = val;
	}
};

struct jogo {
	string nome, genero;
	unsigned short valor;

	void inserir(string nom, string gen, unsigned short val) {
		nome = nom;
		genero = gen;
		valor = val;
	}
};


int main() 
{
	livro livrosemprestados[10];
	jogo jogosemprestados[10];
	short valordigitado;

	string nnome, ggenero;
	unsigned short vvalor;

	cout << "Voce deseja um livro emprestado ou um jogo ? " << endl;
	cout << "Caso queira um livro digite (1) e caso queira um jogo digite (0): " << endl;
	cin >> valordigitado;
	if (valordigitado == 1) {
		cout << "Digite as informacoes do nome, genero e valor: " << endl;
		cin >> nnome;
		cin >> ggenero;
		cin >> vvalor;
		livrosemprestados->inserir(nnome,ggenero,vvalor);
	}
	else if (valordigitado == 0) {
		cout << "Digite as informacoes do nome, genero e valor: " << endl;
		cin >> nnome;
		cin >> ggenero;
		cin >> vvalor;
		jogosemprestados->inserir(nnome,ggenero,vvalor);
	}
	else {
		cout << "Voce nao digitou nenhuma das opcoes perguntadas!";
	}

}