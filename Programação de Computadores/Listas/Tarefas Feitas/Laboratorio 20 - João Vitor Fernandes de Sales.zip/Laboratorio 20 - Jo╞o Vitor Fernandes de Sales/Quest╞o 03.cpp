#include<iostream>
using namespace std;

int main() {
	cout << "Digite um texto (# para finalizar):\n";
	char digito; //para ler o que o usuario vai digitar
	int substituicao = 0; //contador que ira contar quantas vezes uma substituicao foi feita
	while ((digito = cin.get()) != '#')
	{
		if(digito == '.') {
			cout << digito << "!";
			substituicao++; 
		}
		else if (digito == '!') {
			cout << digito << "!";
			substituicao++;
		}
		else {
			cout << digito;
		}
	}
	cout << "\nsubstitui��es = " << substituicao << "\n";
	return 0;
}