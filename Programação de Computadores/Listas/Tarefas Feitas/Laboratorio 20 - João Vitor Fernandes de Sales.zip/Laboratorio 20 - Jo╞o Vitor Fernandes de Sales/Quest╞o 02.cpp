#include<iostream>
using namespace std;
int main() {
	cout << "As �ltimas 10 velocidades registradas: \n";
	short vetor_carros[10];
	short i = 0;
	while (i < 10) {
		cin >> vetor_carros[i];
		i++;
	}
	short j = 0;
	short soma = 0;
	short total = 0;
	while (j < 10) {
		if (vetor_carros[j] > 80) {
			cout << vetor_carros[j] << " Km/h excede o limite = multa de R$" << ((vetor_carros[j]-80) * 8) << endl;
			soma = soma + 1;
			total = ((vetor_carros[j] - 80) * 8) + total;
		}
		else {

		}
		j++;
	}
	cout << soma << " carros foram multados em um valor total de R$" << total;
}