#include<iostream>
using namespace std;

int main() {
	cout << "Calculadora de pre�os por kilometro\n";
	cout << "Digite a dist�ncia do seu percurso em (km):";
	short distancia_km;
	cin >> distancia_km;
		if (distancia_km <= 200) {
			cout << "O seu gasto com gasolina sera de " << distancia_km * 0.50 << " R$.\n";
		}
		else if (distancia_km > 200 || distancia_km <= 400) {
			cout << "O seu gasto com gasolina sera de " << distancia_km * 0.40 << " R$.\n";
		}
		else {
			cout << "O seu gasto com gasolina sera de " << distancia_km * 0.30 << " R$.\n";
		}
}