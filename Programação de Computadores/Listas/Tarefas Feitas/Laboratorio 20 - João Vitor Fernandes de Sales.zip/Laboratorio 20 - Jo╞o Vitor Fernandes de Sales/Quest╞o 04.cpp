#include<iostream>
using namespace std;
int main() {
	cout << "Digite um n�mero inteiro: "; short val01; cin >> val01;
	cout << "Digite outro n�mero inteiro: "; short val02; cin >> val02;
	short i = 0;
	short soma = 0;
	if (val01 < val02) {
		i = val01 + 1;
		while (i < val02) {
			soma = soma + i;
			i++;
		}
	}
	else if (val01 > val02) {
		i = val02 + 1;
		while (i < val01) {
			soma = soma + i;
			i++;
		}
	}
	else{}
	cout << "A soma de todos os valores entre " << val01 << " e " << val02 << ":" << soma;
}