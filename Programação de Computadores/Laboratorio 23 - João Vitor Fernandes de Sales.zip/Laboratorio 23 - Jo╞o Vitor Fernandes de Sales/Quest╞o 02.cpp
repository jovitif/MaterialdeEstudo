#include <iostream>
#include <fstream> 
#include <locale.h> 
using namespace std;

int main()
{
	setlocale(LC_ALL, "portuguese");
	//Declara��o das variaveis:
	char nome[10];            //Vai receber um nome, por�m ao longo do codigo vai ser modificada
	char nome_novo[10];		  //Vai receber o nome da variavel nome, servindo de compara��o
	int total = 0;			  //Vai efetuar a soma da quantidade de palindros, se for palindro total = total + 1
	int i = 0;
	int j = 0;
	char temp;
	char nome_arquivo[] = "palindromos.txt";
	ifstream fin; 
	fin.open(nome_arquivo);
	if (!fin.is_open())
	{
		cout << "Erro na abertura do arquivo!\n";
		system("pause");
		exit(EXIT_FAILURE);
	}
	fin >> nome;
	cout << nome_arquivo << "\n";
	while (!fin.eof())
	{
		fin >> nome;
		for (int i = 0; i <= strlen(nome); i++) {
			nome_novo[i] = nome[i];
		}
		
		for (j = 0, i = strlen(nome) - 1; j < i; i--, j++) {
			temp = nome[i];
			nome[i] = nome[j];
			nome[j] = temp;
		}
		if (strcmp(nome, nome_novo) && strlen(nome) == strlen(nome_novo)) {
		}else {
			total = total + 1;
			cout << nome_novo << "\n";
		}
	}
	fin.close();
	cout << "Foram encontrados " << (total - 1) << " pal�ndromos neste arquivo.";
	return 0;
}