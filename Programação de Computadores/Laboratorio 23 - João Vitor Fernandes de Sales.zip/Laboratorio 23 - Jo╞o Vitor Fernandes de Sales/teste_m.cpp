// teste_m.cpp
#define print cout
#include <iostream>
using namespace std;
int main()
{
	int num = 5;
	cout << num << endl;

	return 0;
}
