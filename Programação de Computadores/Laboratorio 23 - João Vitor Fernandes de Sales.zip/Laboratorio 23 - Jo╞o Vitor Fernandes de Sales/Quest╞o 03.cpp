#include <iostream>
#include <fstream> //Inclus�o da biblioteca para ler o arquivo
#include <locale.h> //Alterar o idioma do programa para portugu�s-br

using namespace std;

struct alunos {
	char name[10]; 
	char sobrenome[10];//Vetor de char para receber varios caracteres referente ao nome
	char turno; //char para receber somente a letra referente ao turno
	short serie; //receber o numero
};

int main()
{
	setlocale(LC_ALL, "portuguese");
	alunos aluno[12]; //Quantidade de alunos na lista
	ifstream fin; //vai ler os dados do arquivo.txt
	fin.open("competi��o intercalasses.txt");
	if (!fin.is_open())
	{
		cout << "Erro na abertura do arquivo!\n";
		system("pause");
		exit(EXIT_FAILURE);
	}

	//O programa vai ler todas as informa��es do arquivo, logo usei um la�o for at� ler a posi��o 11 que � a ultima!
	for (int i = 0; i < 12; i++) {
		fin >> aluno[i].name;
		fin >> aluno[i].sobrenome;
		fin >> aluno[i].turno;
		fin >> aluno[i].serie;
	}
	fin.close();

	//Uso de la�os para separar os alunos por series
	for (int i = 0; i < 12; i++) {
		if (aluno[i].turno == 'M') {
			cout << "\nMatutino ";
				if (aluno[i].serie == 6) {
					cout << " 6a S�rie\n-------------------\n";
					cout << aluno[i].name << " " << aluno[i].sobrenome << " " << aluno[i].turno << aluno[i].serie;
					cout << endl;
				}else if (aluno[i].serie == 7) {
					cout << " 7a S�rie\n-------------------\n";
					cout << aluno[i].name << " " << aluno[i].sobrenome << " " << aluno[i].turno << aluno[i].serie;
					cout << endl;
				}else if (aluno[i].serie == 8) {
					cout << " 8a S�rie\n-------------------\n";
					cout << aluno[i].name << " " << aluno[i].sobrenome << " " << aluno[i].turno << aluno[i].serie;
					cout << endl;
				}
		}else if (aluno[i].turno == 'T') {
			cout << "\nVespertino ";
				if (aluno[i].serie == 6) {
					cout << " 6a S�rie\n-------------------\n";
					cout << aluno[i].name << " " << aluno[i].sobrenome << " " << aluno[i].turno << aluno[i].serie;
					cout << endl;
				}
				if (aluno[i].serie == 7) {
					cout << " 7a S�rie\n-------------------\n";
					cout << aluno[i].name << " " << aluno[i].sobrenome << " " << aluno[i].turno << aluno[i].serie;
					cout << endl;
				}
				if (aluno[i].serie == 8) {
					cout << " 8a S�rie\n-------------------\n";
					cout << aluno[i].name << " " << aluno[i].sobrenome << " " << aluno[i].turno << aluno[i].serie;
					cout << endl;
				}
			}
	}
	return 0;
}