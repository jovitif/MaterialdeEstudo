#include<iostream>
#include<fstream>
#include<string>
#include<cstring>
#include<locale.h>
using namespace std;

int main() {
	setlocale(LC_ALL, "portuguese");
	//Parte 01: acesso ao arquivo teste.cpp
	char tent = 's';
	char name[10];
	string linha;
	string linhae = "cout << num << endl;";
	ifstream arquivo;
	ofstream arquivo2;
	arquivo2.open("teste_m.cpp");
	arquivo2 << "// teste_m.cpp\n#define print cout\n";
	do {
		cout << "Digite o nome do arquivo aqui: ";
		cin >> name;
		arquivo.open(name);

		if (!arquivo.is_open()) {
			cout << "O arquivo n�o foi encontrado com sucesso, deseja tentar novamente (?): ";
			cin >> tent;
		}
		while (!arquivo.eof()) {
			getline(arquivo, linha);
			cout << linha << endl;
			arquivo2 << linha << endl;
			tent = 'n';
		}
	} while (tent != 'n');
	arquivo.close();
	arquivo2.close();
}